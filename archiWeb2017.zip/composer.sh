php composer.phar $*
